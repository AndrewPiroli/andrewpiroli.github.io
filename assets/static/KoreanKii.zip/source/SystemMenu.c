// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2.0.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License 2.0 for more details.

// Copyright (C) 2012	JoostinOnline

#include <stdio.h>
#include <string.h>
#include <gccore.h>
#include <malloc.h>

/*
 This returns the official revision number of your System Menu.

 I found GetSysMenuVersion on pastie.org, no idea who first
 wrote it.  It's in multiple apps too.  Sorry if you were the
 one who first wrote it.  I did make some changes though.

 http://pastie.org/pastes/1093819/
 */
u16 GetSysMenuVersion(void)
{
	static u64 TitleID ATTRIBUTE_ALIGN(32) = 0x0000000100000002ULL;
	static u32 tmdSize ATTRIBUTE_ALIGN(32);

	// Get the stored TMD size for the system menu
	if (ES_GetStoredTMDSize(TitleID, &tmdSize) < 0) return 0;

	signed_blob *TMD = (signed_blob *)memalign(32, (tmdSize+32)&(~31));
	memset(TMD, 0, tmdSize);

	// Get the stored TMD for the system menu
	if (ES_GetStoredTMD(TitleID, TMD, tmdSize) < 0) return 0;

	// Get the system menu version from TMD
	tmd *rTMD = (tmd *)(TMD+(0x140/sizeof(tmd *)));
	u16 version = rTMD->title_version;

	free(TMD);

	// Return the system menu version
	return version;
}

/*
 Checks that your System Menu isn't 4.2 U/E/J or above, which would
 result in a 003 error if you add the Korean key. It also checks for
 for custom versions (Softmod ANY Wii by mauifrog)
*/
bool CheckForSafeRevision(void) {
	//int TerribleRevisions[] = {480, 481, 482, 512, 513, 514};
	u16 SafeRevisions[] = {33, 97, 128, 130, 162, 192, 193, 194, 224, 225, 226, 256, 257, 258, 288, 289, 290, 326, 352, 353, 354, 384,385, 386, 390, 416, 417, 418, 448, 449, 450, 454, 486, 518, 54448, 54449, 54450, 54454};
	//int length = sizeof(TerribleRevisions) / sizeof(int);
	int length = sizeof(SafeRevisions) / sizeof(*SafeRevisions);
	u16 SystemMenuRev = GetSysMenuVersion();
	int i;
	for (i = 0; i < length; i++) {
		if (SystemMenuRev == SafeRevisions[i]) return true;
	}
	return false;
}