// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2.0.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License 2.0 for more details.

// Copyright (C) 2012	JoostinOnline

/*
 KoreanKii by JoostinOnline

 All code in seeprom.c is by tueidj and Team Twiizers, I claim no
 rights to it.  This is simply a very crappy UI for the code.
*/

#include <stdarg.h>

void Initialize(void);
int Menu(void);

//---------------------------------------------------------------------------------
int main(int argc, char **argv) {
//---------------------------------------------------------------------------------
	Initialize();
	Menu();
	return 0;
}
