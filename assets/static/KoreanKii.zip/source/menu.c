// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, version 2.0.

// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License 2.0 for more details.

// Copyright (C) 2012	JoostinOnline

#include <ogc/pad.h>
#include <stdarg.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <wiiuse/wpad.h>

#include "colors.h"

#define VERSION "1.1"
// Only uncomment this if you want to record in Dolphin
//#define VIDEO
// Only uncomment this if you want to test in Dolphin
//#define DOLPHIN

void set_korean(int set);
static void *xfb = NULL;
static GXRModeObj *rmode = NULL;
extern void __exception_setreload(int t);
bool CheckForSafeRevision(void);

bool IsAhbProtDisabled(void) {
	return (*(vu32*)0xcd800064 == 0xFFFFFFFF);
}

void Initialize(void) {
	__exception_setreload(2);
	VIDEO_Init();
	WPAD_Init();
	PAD_Init();
	rmode = VIDEO_GetPreferredMode(NULL);
	xfb = MEM_K0_TO_K1(SYS_AllocateFramebuffer(rmode));
	console_init(xfb,20,20,rmode->fbWidth,rmode->xfbHeight,rmode->fbWidth*VI_DISPLAY_PIX_SZ);
	VIDEO_Configure(rmode);
	VIDEO_SetNextFramebuffer(xfb);
	VIDEO_SetBlack(FALSE);
	VIDEO_Flush();
	VIDEO_WaitVSync();
	if(rmode->viTVMode&VI_NON_INTERLACE) VIDEO_WaitVSync();
}

u32 GetInput(void) {
	WPAD_ScanPads();
	u32 pressed = WPAD_ButtonsDown(0);

	if (pressed)
		return pressed;

	PAD_ScanPads();
	pressed = PAD_ButtonsDown(0);

	if (pressed) {
		if (pressed & PAD_BUTTON_A) return WPAD_BUTTON_A;
		if (pressed & PAD_BUTTON_B) return WPAD_BUTTON_B;
		if (pressed & PAD_BUTTON_START) return WPAD_BUTTON_HOME;
		if (pressed & PAD_TRIGGER_L) return WPAD_BUTTON_MINUS;
		if (pressed & PAD_TRIGGER_R) return WPAD_BUTTON_PLUS;
	}
	return 0;
}

void AreYouSure(int AddKey) {
	// AddKey is 1 if confirming adding key, and 0 if confirming removing it

	if (!CheckForSafeRevision()) {
		SetColors(RED, YELLOW);
		printf("\n\nYou have a non-Korean System Menu (4.2+)!  Adding the Korean key will\n");
		printf("cause a 003 brick unless you have IOS60 patched into your SM IOS!");
	}

	SetColors(BLACK, WHITE);
	printf("\n\nAre you sure you want to risk %sing the Korean key?\n", (AddKey) ? "add" : "remov");
	printf("A: Yes\nB: No\n");
	while(1) {
		u32 pressed = GetInput();

		if (pressed & WPAD_BUTTON_A) {
			printf("\n%sing the Korean key\n", (AddKey) ? "Add" : "Remov");
			#ifndef DOLPHIN
			set_korean(AddKey);
			#endif
			sleep(1);
			#ifdef RECORD
			sleep(25);
			#endif
			printf("Korean key has been successfully %sed", (AddKey) ? "add" : "remov");
			sleep(2);
			#ifdef RECORD
			sleep(50);
			#endif
			exit(0);
		}
		if (pressed & WPAD_BUTTON_B) exit(0);
		}
}


void Menu(void) {
	#ifndef DOLPHIN
	printf("\x1b[2;0H");
	#endif
	SetFgColor(GREEN);
	printf("KoreanKii v%s - www.HacksDen.com\n\n", VERSION);
	printf("SEEPROM code by tueidj and Team Twiizers\n");
	printf("Interface by JoostinOnline\n\n");
	SetFgColor(RED);
	printf("Do not use this program unless you understand the risks.\n\n");
	#ifndef DOLPHIN
	if (!IsAhbProtDisabled()) {
		printf("Error: AHBPROT is not disabled, use the latest HBC\n");
		printf("Exiting...");
		sleep(5);
		exit(0);
	}
	#endif
	sleep(2);
	#ifdef RECORD
	sleep(50);
	#endif
	SetFgColor(WHITE);
	printf("Press + or R to add Korean key\n");
	printf("Press - or L to remove Korean key\n");
	printf("Press HOME or START to exit without making changes");

	while(1) {
		u32 pressed = GetInput();

		if (pressed & WPAD_BUTTON_HOME) exit(0);
		if (pressed & WPAD_BUTTON_PLUS) AreYouSure(1);
		if (pressed & WPAD_BUTTON_MINUS) AreYouSure(0);

		VIDEO_WaitVSync();
	}
}